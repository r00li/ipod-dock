var searchData=
[
  ['read',['read',['../class_bounce.html#ae1936fdf44501992707e6cbaee9bbc76',1,'Bounce']]],
  ['risingedge',['risingEdge',['../class_bounce.html#a3417beb80eb6593d768c2e9884c57aa0',1,'Bounce']]],
  ['rose',['rose',['../class_bounce.html#a9e4187934576e568cdfa8f94efeff6f2',1,'Bounce']]]
];
